package org.apache.camel.example.server;

import org.apache.camel.CamelExecutionException;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.springframework.beans.factory.annotation.Value;

public class RegisterBean {

    @Value("${workername}")
    private String workername;

    @Value("${type}")
    private String type;

    @Produce(uri = "jms:queue:register")
    protected ProducerTemplate producerTemplate;

    public String getWorkername() {
        return workername;
    }

    public void setWorkername(final String workername) {
        this.workername = workername;
    }

    public String getType() {
        return type;
    }

    public void setType(final String type) {
        this.type = type;
    }

    public void create() {

        try {
            final CustomBean bean = new CustomBean();
            bean.setId(1234);
            bean.setName(workername);
            bean.setType(type);
            System.out.println("RegisterBean..from worker....." + bean);
            producerTemplate.sendBody(bean);
        } catch (final CamelExecutionException e) {
            e.printStackTrace();
        }
    }

}
