/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.camel.example.client;

import org.apache.activemq.camel.component.ActiveMQComponent;
import org.apache.camel.CamelContext;
import org.apache.camel.ExchangePattern;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.example.server.JobProcessingRoutes;
import org.apache.camel.example.server.RegisterRoutes;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Client that uses Camel Spring Remoting for very easy integration with the server.
 * <p/>
 * Requires that the JMS broker is running, as well as CamelServer
 */
public final class JobProcessingQueueCamelClientRemoting {
    private JobProcessingQueueCamelClientRemoting() {
        // Helper class
    }

    // START SNIPPET: e1
    public static void main(final String[] args) {
        System.out.println("Notice this client requires that the CamelServer is already running!");
        
        try {
		

        final AbstractApplicationContext context = new ClassPathXmlApplicationContext("camel-manager.xml");

        final CamelContext camel = context.getBean("camel-client-2", CamelContext.class);
        camel.addComponent("jms", ActiveMQComponent.activeMQComponent("tcp://localhost:61610"));
        camel.addRoutes(new RegisterRoutes());
        camel.addRoutes(new JobProcessingRoutes());
        
        // get the camel template for Spring template style sending of messages (= producer)
        final ProducerTemplate camelTemplate = context.getBean("camelTemplate", ProducerTemplate.class);

        System.out.println("Invoking the multiply with 33");
        // as opposed to the CamelClientRemoting example we need to define the service URI in this java code
        final int response = (Integer) camelTemplate.sendBody("jms:queue:numbers", ExchangePattern.InOut, 33);
        System.out.println("... the result is: " + response);

       
      /*   final ConsumerTemplate cTemplate = context.getBean("camelConsumer", ConsumerTemplate.class); 
         System.out.println("Message Consuming started.........."); 
         final     Exchange ex = cTemplate.receive("jms:queue:register"); 
         
         System.out.println("Message received:" + ex.getIn().getBody());*/
         
         
         
     	
		} catch (Exception e) {
			e.printStackTrace();
		}
   

        // we're done so let's properly close the application context
        // IOHelper.close(context);
    }
    // END SNIPPET: e1
    
  /*  @Override
    protected RouteBuilder createRouteBuilder() throws Exception {
        return new RouteBuilder() {
            @Override
            public void configure() throws Exception {
                from("jms:queue:register")
                    .process(new RegisterProcess());
             
          
            }
        };
    }*/

}
