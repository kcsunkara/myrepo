package org.apache.camel.example.process;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.example.server.CustomBean;
import org.springframework.jdbc.core.JdbcTemplate;

public class JobProcess implements Processor {

    private JdbcTemplate jdbc;

    public JobProcess() {
    }

    public void setDataSource(final DataSource ds) {
        jdbc = new JdbcTemplate(ds);
    }

    @Override
    public void process(final Exchange exchange) throws Exception {

        final String bean = exchange.getIn().getBody(String.class);
        System.out.println("..................JobProcess ............................" + bean);
       /* final String sql = "select * from  register_queue";
        final List<CustomBean> customers = new ArrayList<CustomBean>();
        try {

            final List<Map<String, Object>> rows = jdbc.queryForList(sql);
            for (final Map row : rows) {
                final CustomBean customer = new CustomBean();
                customer.setId(Integer.parseInt(String.valueOf(row.get("ID"))));
                customer.setName((String) row.get("NAME"));
                customers.add(customer);
            }
        } catch (final Throwable e) {
            e.printStackTrace();
        }

        System.out.println("&&&&&&&&&&&&&&&&&&&&customers::" + customers);
        exchange.getIn().setBody(bean);*/
    }
}
