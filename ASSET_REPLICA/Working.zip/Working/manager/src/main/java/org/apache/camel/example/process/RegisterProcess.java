package org.apache.camel.example.process;

import javax.sql.DataSource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.example.server.CustomBean;
import org.springframework.jdbc.core.JdbcTemplate;

public class RegisterProcess implements Processor {

    private JdbcTemplate jdbc;

    public RegisterProcess() {
    }

    public void setDataSource(final DataSource ds) {
        jdbc = new JdbcTemplate(ds);
    }

    @Override
    public void process(final Exchange exchange) throws Exception {

        final CustomBean bean = exchange.getIn().getBody(CustomBean.class);
        System.out.println(jdbc+"..................RegisterProcess bean.getName()............................"
                + bean.getName());
        final String sql = "insert into register_queue (id, name,type) values (?, ?,?)";

        try {

            jdbc.update(sql, new Object[] { 99, bean.getName(), bean.getType() });
        } catch (final Throwable e) {
            e.printStackTrace();
        }
        
        System.out.println("..................RegisterProcess new worker inserted...");
        exchange.getIn().setBody(bean);
    }
}
